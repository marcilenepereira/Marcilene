const produtos = [
  { id: 1, nome: "Bolo de Pote", preco: 8.00, imagem: "https://via.placeholder.com/150" },
  { id: 2, nome: "Laço Personalizado", preco: 5.50, imagem: "https://via.placeholder.com/150" },
  { id: 3, nome: "Consultoria de Maternidade", preco: 40.00, imagem: "https://via.placeholder.com/150" },
];

const carrinho = [];

function carregarProdutos() {
  const container = document.getElementById("produtos");
  produtos.forEach(prod => {
    const div = document.createElement("div");
    div.className = "produto";
    div.innerHTML = `
      <img src="${prod.imagem}" alt="${prod.nome}" />
      <h3>${prod.nome}</h3>
      <p>R$ ${prod.preco.toFixed(2)}</p>
      <button onclick="adicionarAoCarrinho(${prod.id})">Adicionar</button>
    `;
    container.appendChild(div);
  });
}

function adicionarAoCarrinho(id) {
  const item = produtos.find(p => p.id === id);
  carrinho.push(item);
  atualizarCarrinho();
}

function atualizarCarrinho() {
  document.getElementById("quantidade").innerText = carrinho.length;
  const lista = document.getElementById("itensCarrinho");
  lista.innerHTML = "";
  let total = 0;
  carrinho.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
    lista.appendChild(li);
    total += item.preco;
  });
  document.getElementById("total").innerText = total.toFixed(2);
}

document.getElementById("verCarrinho").addEventListener("click", () => {
  document.getElementById("carrinho").classList.toggle("oculto");
});

carregarProdutos();
